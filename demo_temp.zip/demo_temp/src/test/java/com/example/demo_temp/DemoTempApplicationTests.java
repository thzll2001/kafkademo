package com.example.demo_temp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoTempApplicationTests {

    @Test
    void contextLoads() {
    }

}
