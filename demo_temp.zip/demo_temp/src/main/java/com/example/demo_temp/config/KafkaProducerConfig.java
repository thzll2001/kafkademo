package com.example.demo_temp.config;

import com.fasterxml.jackson.databind.ser.std.StringSerializer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;


@EnableKafka
@Configuration
//@EnableAutoConfiguration
public class KafkaProducerConfig {


    @Value(value = "209.209.9.250:9091,209.209.9.250:9092,209.209.9.250:9093")
    private String bootstrapAddress;
    @Bean
    @Qualifier("producerFactory")
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(
          ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
          bootstrapAddress);
        configProps.put(
          ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, 
          "org.apache.kafka.common.serialization.StringSerializer");
        configProps.put(
          ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer"
                );
        configProps.put(ProducerConfig.ACKS_CONFIG,"all");
             //   StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }

    @Bean
    @Qualifier("producerFactory2")
    public ProducerFactory<String, Object> producerFactory2() {
        Map<String, Object> configProps = new HashMap<>();
        configProps.put(
                ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                bootstrapAddress);
        configProps.put(
                ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer");
        configProps.put(
                ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                "org.apache.kafka.common.serialization.StringSerializer"
        );
        configProps.put(ProducerConfig.ACKS_CONFIG,"all");
        //   StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(configProps);
    }
    @Bean(name="kafkaTemplate")
    @Qualifier("kafkaTemplate")
    public KafkaTemplate<String, String> kafkaTemplate() {
        return new KafkaTemplate<>(producerFactory());
    }

    @Bean(name="kafkaTemplate2")
    @Qualifier("kafkaTemplate2")
    public KafkaTemplate<String, Object> kafkaTemplate2() {
        return new KafkaTemplate<>(producerFactory2());
    }

}