package com.example.demo_temp.service;

public interface KafkaProduceService {
    public void sendMessage(String topicName, String message);
}
