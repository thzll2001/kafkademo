package com.example.demo_temp.controller;

import com.example.demo_temp.model.MyConsumer;
import com.example.demo_temp.service.KafkaProduceService;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.http.HttpClient;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@RestController
public class KafkaController {

//    RestTemplate restTemplate() throws Exception {
//        SSLContext sslContext = new SSLContextBuilder()
//                .loadTrustMaterial(trustStore.getURL(), trustStorePassword.toCharArray())
//                .build();
//        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
//        HttpClient httpClient = HttpClients.custom()
//                .setSSLSocketFactory(socketFactory)
//                .build();
//        HttpComponentsClientHttpRequestFactory factory =
//                new HttpComponentsClientHttpRequestFactory(httpClient);
//        return new RestTemplate(factory);
//    }
    @Resource
    private KafkaProduceService kafkaProduceService;

    @GetMapping("/hello")
    public String getHello(){

        return "hello";
    }

//    @Resource
//    private RestTemplate restTemplate;

    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/testrest")
    public ResponseEntity<String> getRest(){
        ResponseEntity<String>  entity = restTemplate.getForEntity("https://localhost/hello", String.class);
        return ResponseEntity.ok(entity.getBody());
    // return ResponseEntity.ok("test");
    }

   @GetMapping("/test/{msg}")
   public String getTest(@PathVariable String msg){
       kafkaProduceService.sendMessage("test",msg);
       return "hello";
   }
   @GetMapping("/listmsg")
    public List<String> getMsgs(){
       return MyConsumer.getMsgList();

   }

}
