package com.example.demo_temp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTempApplication {

    public static void main(String[] args) {
        SpringApplication.run(DemoTempApplication.class, args);
    }

}
