package com.example.demo_temp.config;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import javax.net.ssl.SSLContext;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.CertificateException;


import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;

//import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@Configuration
public class AppConfig {
////
//	@Value("${trust.store}")
//	private KeyStore trustStore;
////
//	@Value("${trust.store.password}")
//	private String trustStorePassword;
//	@Bean
//	@Bean
//	public RestTemplate restTemplate() throws NoSuchAlgorithmException, KeyStoreException, KeyManagementException, IOException, UnrecoverableKeyException, CertificateException {
		// RestTemplate restTemplate = new RestTemplate();
		//设置中文乱码问题方式一
		// restTemplate.getMessageConverters().add(1,new StringHttpMessageConverter(Charset.forName("UTF-8")));
		// 设置中文乱码问题方式二
		// restTemplate.getMessageConverters().set(1,new StringHttpMessageConverter(StandardCharsets.UTF_8)); // 支持中文编码
		//return new RestTemplate();

//
//		SSLContext sslContext = new SSLContextBuilder()
//				.loadTrustMaterial(trustStore,null)// trustStorePassword.toCharArray())
//				.build();
//		SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
//		CloseableHttpClient httpClient = HttpClients.custom()
//				.setSSLSocketFactory(socketFactory)
//				.build();
//		HttpComponentsClientHttpRequestFactory factory =
//				new HttpComponentsClientHttpRequestFactory(httpClient);
//		return new RestTemplate(factory);
//
//		KeyStore clientStore = KeyStore.getInstance("PKCS12");
//		clientStore.load(new FileInputStream("C:\\workspace\\kafka\\demo_temp\\src\\main\\resources\\keystore\\mtkitch.p12"), "change".toCharArray());
//
//		SSLContext sslContext = SSLContextBuilder.create()
//				.setProtocol("TLS")
//				.loadKeyMaterial(clientStore, "certificate-password".toCharArray())
//				.loadTrustMaterial(clientStore,null)//new TrustSelfSignedStrategy())
//				.build();
//
//		SSLConnectionSocketFactory sslConnectionSocketFactory = new SSLConnectionSocketFactory(sslContext);
//		CloseableHttpClient httpClient = HttpClients.custom()
//				.setSSLSocketFactory(sslConnectionSocketFactory)
//				.build();
//
//		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
//
//		return new RestTemplate(requestFactory);
		//}


//	@Bean
//	public RestTemplate restTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
//			CertificateException, MalformedURLException, IOException {
//
//		SSLContext sslContext = new SSLContextBuilder()
//				.loadTrustMaterial(trustStore.getURL(), trustStorePassword.toCharArray()).build();
//		SSLConnectionSocketFactory sslConFactory = new SSLConnectionSocketFactory(sslContext);
//
//		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslConFactory).build();
//		ClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
//		return new RestTemplate(requestFactory);
//	}
	@Bean
	RestTemplate restTemplate() throws Exception {
        String trustStorePassword="change";
        char[] chs= trustStorePassword.toCharArray();
        //"C:/workspace/kafka/demo_temp/resource/:keystore/mtkitch.p12
        String fileName = "keystore/mtkitch_2.p12";
        System.out.println("getResourceAsStream : " + fileName);

        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource(fileName);

        InputStream is = classLoader.getResourceAsStream(fileName);
        InputStreamReader streamReader =
                new InputStreamReader(is, StandardCharsets.UTF_8);
        BufferedReader reader = new BufferedReader(streamReader) ;

            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }

            File f1= new File("C:/workspace/kafka/demo_temp/src/main/resources/keystore/mtkitch_2.p12");

        SSLContext sslContext = new SSLContextBuilder()
				.loadTrustMaterial(f1,chs)
        //new File(resource.toURI()),chs)
				.build();
		SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
		CloseableHttpClient httpClient = HttpClients.custom()
				.setSSLSocketFactory(socketFactory)
				.build();
		HttpComponentsClientHttpRequestFactory factory =
				new HttpComponentsClientHttpRequestFactory(httpClient);
		return new RestTemplate(factory);
	}
}