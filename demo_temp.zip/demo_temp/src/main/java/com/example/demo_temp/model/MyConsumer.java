package com.example.demo_temp.model;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class MyConsumer {

    static private final ConcurrentHashMap<String,String> msgMap = new ConcurrentHashMap();
    @KafkaListener(topics= {"test"}, groupId="groupid")
      public void consume(String quote) {

        msgMap.put(String.valueOf(UUID.randomUUID()),quote) ;
        System.out.println("received= " + quote);
      }

      public static List<String> getMsgList(){
        List<String> ls = new ArrayList<>() ;
        msgMap.forEach((k,v)->{
            ls.add(v);
        });
        return ls;
      }
  }
