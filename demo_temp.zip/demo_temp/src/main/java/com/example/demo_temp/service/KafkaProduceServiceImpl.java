package com.example.demo_temp.service;

import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.PartitionOffset;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@RequiredArgsConstructor
@Service
@EnableKafka
public class KafkaProduceServiceImpl implements KafkaProduceService{


    @Autowired
    private final KafkaTemplate<String, String> kafkaTemplate;
    @Autowired
    private final KafkaTemplate<String, Object> kafkaTemplate2;
//
//    @KafkaListener(topics = "topicName")
//    public void listenWithHeaders(
//            @Payload String message,
//            @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
//        System.out.println(
//                "Received Message: " + message
//                        + "from partition: " + partition);
//    }
//
//    @KafkaListener(
//            topicPartitions = @TopicPartition(topic = "topicName",
//                    partitionOffsets = {
//                            @PartitionOffset(partition = "0", initialOffset = "0"),
//                            @PartitionOffset(partition = "3", initialOffset = "0")}),
//            containerFactory = "partitionsKafkaListenerContainerFactory")
//    public void listenToPartition(
//            @Payload String message,
//            @Header(KafkaHeaders.RECEIVED_PARTITION_ID) int partition) {
//        System.out.println(
//                "Received Message: " + message
//                        + "from partition: " + partition);
//    }

//    @KafkaListener(topics = "topicName", groupId = "groupid")
//    public void listenGroup(String message) {
//        System.out.println("Received Message in group foo: " + message);
//    }

//props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class.getName());
//props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);

    private Object mapObject(){
        Object obj = new Object();
        ProducerRecord<String, Object> record=
                new ProducerRecord<String, Object>("1",obj);
        ListenableFuture<SendResult<String, Object>> future =
                kafkaTemplate2.send( record);
//        try {
//
//           // RecordMetadata recordMetadata =kafkaTemplate.send((Message<Object>) record).get();
//                    //producer.send(record).get();
//
//            String message = String.format("sent message to topic:%s partition:%s  offset:%s",
//                    recordMetadata.topic(), recordMetadata.partition(), recordMetadata.offset());
//            System.out.println(message);
//
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }
         return obj;

    }

    @Override
    public void sendMessage(String topicName, String message) {
//        kafkaTemplate.send(topicName, msg);
       ListenableFuture<SendResult<String, String>> future =
                kafkaTemplate.send(topicName, message);

        future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

            @Override
            public void onSuccess(SendResult<String, String> result) {
                System.out.println("Sent message=[" + message +
                        "] with offset=[" + result.getRecordMetadata().offset() + "]");
            }
            @Override
            public void onFailure(Throwable ex) {
                System.out.println("Unable to send message=["
                        + message + "] due to : " + ex.getMessage());
            }
        });
    }

//    @KafkaListener(topics = "test", groupId = "groupid")
//    public void listenGroupFoo(String message) {
//        System.out.println("Received Message in group foo: " + message);
//    }
}
